# SHANE-Digital-Assistant
One aspect of my AI named S.H.A.N.E., is the voice-command digital assistant capabilities like Alexa or Siri. This will be where I store all the files for the command-drive systems. Check out my YouTube channel! Here's a list of the videos specifically tied to this project.

Video #113 - Introduction to the object-orientated programming intermediate-level version of this project: https://youtu.be/GYJKjHMBpDI

I'm a self-taught programmer, so I look forward to your CONSTRUCTIVE feedback.

I recommend installing PyAudio first, before installing Speech Recognition or Python-text-to-Speech (pyttsx3).
You'll need to go here: https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio and find the correct .whl file to properly install PyAudio on Windows.
For example, I had to download PyAudio‑0.2.11‑cp38‑cp38‑win_amd64.whl because I have Python 3.8 installed and I have a 64-bit version of windows.
To install a .whl file, download the file. Assuming it downloaded to your Downloads file, open the Downloads file folder. Right click on the name of the file and copy it. Then type cmd in the file explorer bar. In the command prompt, type pip install (copy and paste the file name) and then add .whl to the name.

It should look like this: C:\your filepath\Downloads> pip install PyAudio‑0.2.11‑cp38‑cp38‑win_amd64.whl

You should be good to install SpeechRecognition and pyttsx3~=2.71 from the requirements.txt file.

# Update 29 Dec 20
In Video #119 on my YouTube channel, I made significant updates to S.H.A.N.E. I've updated the files in the Github. Watch the video here: https://youtu.be/qhITM2q_FyQ
