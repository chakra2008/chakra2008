# Go here to get your own API key:  https://openweathermap.org/api  
OPENWEATHER = 'ENTER YOUR API KEY HERE'
