import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from getpass import getpass
from webdriver_manager.chrome import ChromeDriverManager


username = input("Enter in your username: ")
password = getpass("Enter your password: ")
driver = webdriver.Chrome(ChromeDriverManager().install())
driver.get("https://github.com/login")
username_textbox = driver.find_element_by_id("login_field")
username_textbox.send_keys(username)

password_textbox = driver.find_element_by_id("password")
password_textbox.send_keys(password)
password_textbox.send_keys(Keys.ENTER).perform()

login_button = driver.find_element_by_id("u_0_3_+Q")
login_button.click












